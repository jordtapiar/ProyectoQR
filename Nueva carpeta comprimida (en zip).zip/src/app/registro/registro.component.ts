import { Component } from '@angular/core';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent {
  usuario: any = {}; // Objeto para almacenar los datos del usuario

  onSubmit() {
    // Aquí puedes manejar la lógica de envío del formulario
    // Por ejemplo, enviar los datos al servidor o realizar la validación
    console.log('Datos del usuario:', this.usuario);
  }
}
